--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET search_path = public, pg_catalog;

--
-- Data for Name: dash; Type: TABLE DATA; Schema: public; Owner: dispatcher
--

COPY dash (id, name, body, modified) FROM stdin;
\.
COPY dash (id, name, body, modified) FROM '$$PATH$$/2897.dat';

--
-- Data for Name: dash_group; Type: TABLE DATA; Schema: public; Owner: dispatcher
--

COPY dash_group (dash_id, group_id) FROM stdin;
\.
COPY dash_group (dash_id, group_id) FROM '$$PATH$$/2898.dat';

--
-- Name: dash_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatcher
--

SELECT pg_catalog.setval('dash_id_seq', 24, true);


--
-- PostgreSQL database dump complete
--

